<div class="box shadow pb-1">
    <p class="f-14 text-center text-light-blue">
        &copy; 2022 HFS | All rights reserved
    </p>
</div>
<div class="overlay"></div>
</div>
</div>



<script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.6.0/umd/popper.min.js"></script>
<script src="../assets/js/layout.js"></script>
<script src="../assets/js/app.js"></script>
</body>

</html>