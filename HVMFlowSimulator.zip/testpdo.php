<?php
if (class_exists('PDO')) {
  print "PDO is installed"; 
}
else {
  print "PDO NOT installed";
}

phpinfo();
?>