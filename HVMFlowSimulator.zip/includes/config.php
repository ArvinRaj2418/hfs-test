<?php

// define("SITE_URL", "http://localhost/hfs/");
// define("SITE_ROOT", $_SERVER['DOCUMENT_ROOT'] . '/hfs/');

define("SITE_URL", "https://HVMFlowSimulator2.apps1-fm-int.icloud.intel.com/");
define("SITE_ROOT", $_SERVER['DOCUMENT_ROOT'] . '/');

// Dev Database Configuration
// const DB_SERVER = "mysql:host=localhost;dbname=hfs;charset=utf8mb4";
// const DB_USERNAME = "root";
// const DB_PASSWORD = "";

// Pro Database Configuration
const DB_SERVER = "pgsql:host=postgres5903-lb-fm-in.dbaas.intel.com;port=5433;dbname=test3";
const DB_USERNAME = "test3_so";
const DB_PASSWORD = "iI2F80dW9PsQcOa";

// Email Configuration
//const SMTP_HOST = "SMTP HOST";
//const SMTP_PORT = SMTP_PORT;
//const USERNAME = "Email";
//const PASSWORD = "Password";
//const SENDER = "HFS";

/* const SMTP_HOST = "smtp.zoho.com";
const SMTP_PORT = 465;
const USERNAME = "sa@zohomail.com";
const PASSWORD = "!!!AaA111";
const SENDER = "HFS"; */

?>