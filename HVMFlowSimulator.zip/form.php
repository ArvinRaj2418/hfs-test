<?php

var_dump($_POST);

?>

<form action="" method="post">

    <div id="newDiv">
        <div>
            <input disabled type="text" name="name">
        </div>
    </div>

    <div>
        <input type="text" name="age">
    </div>

    <button name="submit">Submit</button>
</form>
